#pragma once

void connectToWiFi();
